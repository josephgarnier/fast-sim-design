/******************************************************************************
* Copyright 2019-present, Joseph Garnier
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
******************************************************************************/

#include "chunk.h"

namespace FastSimDesign {


	void Chunk::update(const QTime& oDeltaTime) noexcept
	{
		//	m_oSystems.updateAll(oDeltaTime);
		//	m_oEntities.update();
	}
}
