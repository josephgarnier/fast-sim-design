/******************************************************************************
* Copyright 2019-present, Joseph Garnier
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
******************************************************************************/

#pragma once

#ifndef FAST_SIM_DESIGN_CHUNK_DATA_PROVIDER_H
#define FAST_SIM_DESIGN_CHUNK_DATA_PROVIDER_H

#include "chunk.h"

namespace FastSimDesign {
	class ChunkDataProvider
	{
	public:
		explicit ChunkDataProvider() = default; // Default constructor
		ChunkDataProvider(ChunkDataProvider const&) = default; // Copy constructor
		ChunkDataProvider(ChunkDataProvider&&) = default; // Move constructor
		ChunkDataProvider& operator=(ChunkDataProvider const&) = default; // Copy assignment operator
		ChunkDataProvider& operator=(ChunkDataProvider&&) = default; // Move assignment operator
		virtual ~ChunkDataProvider() = default; // Destructor
		
		Chunk loadChunk(int iXCoord, int iYCoord) noexcept;
	protected:
	private:
	};
}
#endif
