/******************************************************************************
* Copyright 2019-present, Joseph Garnier
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
******************************************************************************/

#pragma once

#ifndef FAST_SIM_DESIGN_MAP_WRAPPER_H
#define FAST_SIM_DESIGN_MAP_WRAPPER_H

#include "tiled/map.h"
#include "layer.h"
#include "QGraphicsObject"

namespace FastSimDesign {
	class Map final : public QGraphicsItem
	{
	public:
		explicit Map(Tiled::Map const* const pTiledMap, Tiled::MapRenderer const* const pTiledRenderer, QGraphicsItem* pParent = Q_NULLPTR) noexcept; // Default constructor
		virtual ~Map() = default; // Destructor

		virtual QRectF boundingRect() const noexcept override;
		virtual void paint(QPainter* pPainter, QStyleOptionGraphicsItem const * pOption, QWidget* pWidget = Q_NULLPTR) noexcept override;
		
		inline Tiled::Map const* getTiledMap() const noexcept { return m_pTiledMap; }

	protected:
	private:
		Tiled::Map const * const m_pTiledMap;
		Tiled::MapRenderer const * const m_pTiledRenderer;
		
		QVector<QSharedPointer<Layer>> m_oLayers;
		QSharedPointer<Layer> m_oCollisionLayer;
		QSharedPointer<Layer> m_oEntitiesLayer;
	};
}
#endif
