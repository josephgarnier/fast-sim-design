/******************************************************************************
* Copyright 2019-present, Joseph Garnier
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
******************************************************************************/

#include "layer.h"
#include "QStyleOptionGraphicsItem"

namespace FastSimDesign {
	/*****************************************************************************
Methods
*****************************************************************************/
	Layer::Layer(Tiled::TileLayer const* const pTiledLayer, Tiled::MapRenderer const* const pTiledRenderer, QGraphicsItem* pParent) noexcept
		: QGraphicsItem{pParent}
		, m_pTiledLayer{pTiledLayer}
		, m_pTiledRenderer{pTiledRenderer}
	{
		setFlag(QGraphicsItem::ItemUsesExtendedStyleOption);
		setOpacity(m_pTiledLayer->opacity());
		setPos(m_pTiledLayer->offset());
	}

	QRectF Layer::boundingRect() const noexcept
	{
		return m_pTiledRenderer->boundingRect(m_pTiledLayer->bounds());
	}

	void Layer::paint(QPainter* pPainter, QStyleOptionGraphicsItem const* pOption, QWidget* pWidget /* unused */) noexcept
	{
		Q_UNUSED(pWidget);
		m_pTiledRenderer->drawTileLayer(pPainter, m_pTiledLayer, pOption->rect);
	}
}
