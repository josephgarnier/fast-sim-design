/******************************************************************************
* Copyright 2019-present, Joseph Garnier
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
******************************************************************************/

#pragma once

#ifndef FAST_SIM_DESIGN_LAYER_H
#define FAST_SIM_DESIGN_LAYER_H

#include "QGraphicsItem"
#include "tiled/tilelayer.h"
#include "tiled/maprenderer.h"

namespace FastSimDesign {
	class Layer final : public QGraphicsItem
	{
	public:
		explicit Layer(Tiled::TileLayer const* const pTiledLayer, Tiled::MapRenderer const* const pTiledRenderer, QGraphicsItem* pParent = Q_NULLPTR) noexcept; // Default constructor
		virtual ~Layer() = default; // Destructor

		virtual QRectF boundingRect() const noexcept override;
		virtual void paint(QPainter* pPainter, QStyleOptionGraphicsItem const* pOption, QWidget* pWidget = Q_NULLPTR) noexcept override;

	protected:
		Tiled::TileLayer const* const m_pTiledLayer;
		Tiled::MapRenderer const* const m_pTiledRenderer;

	private:
	};
}
#endif
