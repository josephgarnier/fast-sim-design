/******************************************************************************
* Copyright 2019-present, Joseph Garnier
* All rights reserved.
*
* This source code is licensed under the license found in the
* LICENSE file in the root directory of this source tree.
******************************************************************************/

#pragma once

#ifndef FAST_SIM_DESIGN_CHUNK_H
#define FAST_SIM_DESIGN_CHUNK_H

#include "entity/entity_manager.h"
#include "entity/system_manager.h"
#include "QTime"
#include "map.h"
#include "map_viewer.h"

namespace FastSimDesign {
	class Chunk final : public QObject
	{
		Q_OBJECT
	public:
		explicit Chunk(Tiled::Map const* const pTiledMap, Tiled::MapRenderer const* const pTiledRenderer, QObject* pParent = Q_NULLPTR) noexcept; // Default constructor
		virtual ~Chunk(); // Destructor
		
		void update(QTime const& oDeltaTime) noexcept;
		
		EntityManager& getEntityManager() const noexcept;
		QVector<QSharedPointer<Entity>> const& getEntities() const noexcept;
		template<typename... EntityArgs>
		QSharedPointer<Entity> emplaceEntity(EntityArgs&&... args) noexcept;
		void destroyEntity(QSharedPointer<Entity> const& oEntity);
		void destroyEntity(int iEntityId);
		
		template<typename... EntityArgs>
		QSharedPointer<Entity> emplace(EntityArgs&&... args) noexcept;
		void push_back(QSharedPointer<Entity> oEntity) noexcept;
		void remove(QSharedPointer<Entity> const& oEntity) noexcept;
		void remove(int iEntityId) noexcept;
		
		void addLayer(TerrainLayer* pLayer);
    void removeTerrainLayer(TerrainLayer* terrainLayer);
    std::vector<TerrainLayer*> terrainLayers();

    QGraphicsScene* scene();
		
		
		
	protected:
	private:
		EntityManager m_oEntities;
		SystemManager m_oSystems;
		
		Tiled::Map const * const m_pTiledMap;
		Tiled::MapRenderer const * const m_pTiledRenderer;
		MapViewer* m_pViewer;
		
		QVector<QSharedPointer<Layer>> m_oLayers;
		QSharedPointer<Layer> m_oCollisionLayer;
		QSharedPointer<Layer> m_oEntitiesLayer;
	};
}
#endif
